package com.example.dynaisland

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(36), dp(24), dp(24))
            setBackgroundColor(Color.rgb(12, 12, 15))
        }
        val title = TextView(this).apply {
            text = "DynaIsland"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Dynamic Island для Samsung Galaxy"
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(28))
        }
        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(actionButton("1. Разрешить отображение поверх приложений") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        })
        layout.addView(actionButton("2. Разрешить доступ к уведомлениям") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        layout.addView(actionButton("3. Запустить DynaIsland") {
            if (Settings.canDrawOverlays(this)) {
                startService(Intent(this, IslandService::class.java))
            } else {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        })
        layout.addView(actionButton("Остановить островок") {
            stopService(Intent(this, IslandService::class.java))
        })
        val note = TextView(this).apply {
            text = "Системные баннеры Android остаются под контролем One UI. DynaIsland показывает собственную компактную карточку и не удаляет уведомления из шторки."
            textSize = 13f
            setTextColor(Color.GRAY)
            setPadding(0, dp(24), 0, 0)
        }
        layout.addView(note)
        setContentView(layout)
    }

    private fun actionButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(10) }
        }
}
