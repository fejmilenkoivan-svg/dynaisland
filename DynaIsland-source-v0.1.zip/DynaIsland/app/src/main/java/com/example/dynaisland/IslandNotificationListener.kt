package com.example.dynaisland

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.content.Intent
import android.app.Notification

class IslandNotificationListener : NotificationListenerService() {
    companion object {
        const val ACTION_NEW_NOTIFICATION = "com.example.dynaisland.NEW_NOTIFICATION"
        const val EXTRA_TEXT = "text"
    }

    // A notification key is delivered once per post; updates reuse the key.
    // We intentionally don't remove or suppress Android's original notification.
    private val lastSeen = LinkedHashMap<String, Long>()

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val now = System.currentTimeMillis()
        val previous = lastSeen[sbn.key]
        if (previous != null && now - previous < 1200L) return
        lastSeen[sbn.key] = now
        if (lastSeen.size > 100) lastSeen.entries.iterator().let { it.next(); it.remove() }

        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val body = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val app = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (_: Exception) { sbn.packageName }
        val message = listOf(app, title, body).filter { it.isNotBlank() }.joinToString(": ")
        if (message.isNotBlank()) {
            sendBroadcast(Intent(ACTION_NEW_NOTIFICATION).setPackage(packageName).putExtra(EXTRA_TEXT, message))
        }
    }
}
