package com.example.dynaisland

import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class IslandService : Service() {
    private lateinit var wm: WindowManager
    private var island: LinearLayout? = null
    private var detail: TextView? = null
    private var expanded = false
    private var batteryPct = -1

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            if (level >= 0 && scale > 0) {
                batteryPct = level * 100 / scale
                showMessage("Заряд батареи: $batteryPct%")
            }
        }
    }

    private val notificationReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val text = intent?.getStringExtra(IslandNotificationListener.EXTRA_TEXT) ?: return
            showMessage(text.take(100))
        }
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createIsland()
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val filter = IntentFilter(IslandNotificationListener.ACTION_NEW_NOTIFICATION)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(notificationReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(notificationReceiver, filter)
        }
    }

    private fun createIsland() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(26, 12, 26, 12)
            setBackgroundColor(Color.BLACK)
        }
        val title = TextView(this).apply {
            text = "●  DynaIsland"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        detail = TextView(this).apply {
            text = "Готов к работе"
            textSize = 11f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            visibility = TextView.GONE
        }
        container.addView(title)
        container.addView(detail)
        container.setOnClickListener {
            expanded = !expanded
            detail?.visibility = if (expanded) TextView.VISIBLE else TextView.GONE
            val lp = container.layoutParams
            if (lp != null) {
                lp.width = if (expanded) 300 else 190
                wm.updateViewLayout(container, lp)
            }
        }
        val params = WindowManager.LayoutParams(
            190, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = 8
        }
        island = container
        wm.addView(container, params)
    }

    private fun showMessage(message: String) {
        detail?.text = message
        detail?.visibility = TextView.VISIBLE
        expanded = true
        island?.let { view ->
            val lp = view.layoutParams
            lp.width = 300
            wm.updateViewLayout(view, lp)
        }
    }

    override fun onDestroy() {
        try { unregisterReceiver(batteryReceiver) } catch (_: Exception) {}
        try { unregisterReceiver(notificationReceiver) } catch (_: Exception) {}
        island?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        island = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
